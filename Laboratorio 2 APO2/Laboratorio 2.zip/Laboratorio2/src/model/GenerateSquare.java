package model;

import Exceptions.NotADirectionException;
import Exceptions.NotAValidMatrixException;

public class GenerateSquare {
	//Direcciones
	public final static String NorOeste = "NO";
	public final static String NorEste = "NE";
	public final static String SurOeste = "SO";
	public final static String SurEste = "SE";
	//Pocisiones
	
	public final static String Top = "Top";
	public final static String Bot = "Bot";
	public final static String Right = "Right";
	public final static String Left = "Left";
	
	
	private int[][] matrix;

	public GenerateSquare(int[][] matrix){
		this.setMatrix(matrix);
	}
	
	public int MagicC(int side) {
		int answer = 0;
		answer = side*((side * side) + 1);
		answer = answer/2;
		
		
		return answer;
	}
	 
	
	public void fillSquare(String position, String Direction) {
		switch(position) {
		
		case(GenerateSquare.Top):
		int number = 1;
		int length = matrix.length;
		    
		int x = 0;
		int y = 0;
		
		int PX = 0;
		int PY = 0;
		
		y = matrix.length/2;
		
			
			
			switch(Direction) {
			
			case(GenerateSquare.NorOeste):
			
				while(number <= length*length) {
					
					if(matrix[x][y] == 0) {
						matrix[x][y] = number;
						number++;
					
					}else {
						if(matrix[PX+1][PY] == 0) {
							
						x = PX+1;
						y = PY;
					
					if(x<0) {
						x = length -1 ;
						PX = x;
					}
					if(x > length-1) {
						x = 0;
						PX = x;
					}
			
					
					matrix[x][y] = number;
					number++;
						}
					}
					
					PX = x;
					PY = y;
					x--;
					y--;
					
					if(x<0) {
						x = length -1;
					}
					
					if(y < 0) {
						y = length - 1;
					}
					if(length-1< x) {
						x = 0;
					}
					if(length-1 < y) {
						y =0;
					}
					
					
				}
				
				
				break;
			
			case(GenerateSquare.NorEste):
				
                while(number <= length*length) {
					
					if(matrix[x][y] == 0) {
						matrix[x][y] = number;
						number++;
					
					}else {
						if(matrix[PX+1][PY] == 0) {
							
						x = PX+1;
						y = PY;
					
					if(x<0) {
						x = length -1 ;
						PX = x;
					}
					if(x > length-1) {
						x = 0;
						PX = x;
					}
			
					
					matrix[x][y] = number;
					number++;
						}
					}
					
					PX = x;
					PY = y;
					x--;
					y++;
					
					if(x<0) {
						x = length -1;
					}
					
					if(y < 0) {
						y = length - 1;
					}
					if(length-1< x) {
						x = 0;
					}
					if(length-1 < y) {
						y =0;
					}
					
					
				}
				
				
				
				break;
			
			}
				
				break;
		
		
		
        case(GenerateSquare.Bot):
        number = 1;
		 length = matrix.length;
		    
		 x = 0;
		 y = 0;
		
		 PX = 0;
		 PY = 0;
		
		y = matrix.length/2;
        x = matrix.length - 1;	
        	
        	switch(Direction) {
        	   
        	case(GenerateSquare.SurOeste):
            
        		 while(number <= length*length) {
 					
 					if(matrix[x][y] == 0) {
 						matrix[x][y] = number;
 						number++;
 					
 					}else {
 						if(matrix[PX+1][PY] == 0) {
 							
 						x = PX+1;
 						y = PY;
 					
 					if(x<0) {
 						x = length -1 ;
 						PX = x;
 					}
 					if(x > length-1) {
 						x = 0;
 						PX = x;
 					}
 			
 					
 					matrix[x][y] = number;
 					number++;
 						}
 					}
 					
 					PX = x;
 					PY = y;
 					x++;
 					y--;
 					
 					if(x<0) {
 						x = length -1;
 					}
 					
 					if(y < 0) {
 						y = length - 1;
 					}
 					if(length-1< x) {
 						x = 0;
 					}
 					if(length-1 < y) {
 						y =0;
 					}
 					
 				
 				}
        		
        		break;
        	
        	case(GenerateSquare.SurEste):
        		
        		 while(number <= length*length) {
  					
  					if(matrix[x][y] == 0) {
  						matrix[x][y] = number;
  						number++;
  					
  					}else {
  						if(matrix[PX+1][PY] == 0) {
  							
  						x = PX+1;
  						y = PY;
  					
  					if(x<0) {
  						x = length -1 ;
  						PX = x;
  					}
  					if(x > length-1) {
  						x = 0;
  						PX = x;
  					}
  			
  					
  					matrix[x][y] = number;
  					number++;
  						}
  					}
  					
  					PX = x;
  					PY = y;
  					x++;
  					y++;
  					
  					if(x<0) {
  						x = length -1;
  					}
  					
  					if(y < 0) {
  						y = length - 1;
  					}
  					if(length-1< x) {
  						x = 0;
  					}
  					if(length-1 < y) {
  						y =0;
  					}
  					
  					
  				}
        		
        		
        		break;
        	
        	}
        	
        	
        	break;
        	
        	
		case(GenerateSquare.Left):
        	
		number = 1;
		length = matrix.length;
		    
		 x = 0;
		 y = 0;
		
		 PX = 0;
		 PY = 0;
		
      x = matrix.length/2;
        	
        	
            switch(Direction) {
			
			case(GenerateSquare.NorOeste):
				
				
          while(number <= length*length) {
					System.out.println(x);
					System.out.println(y);
					if(matrix[x][y] == 0) {
						matrix[x][y] = number;
						number++;
					
					}else {
						if(matrix[PX][PY+1] == 0) {
							
						x = PX;
						y = PY+1;
					
					if(x<0) {
						x = length -1 ;
						PX = x;
					}
					if(x > length-1) {
						x = 0;
						PX = x;
					}
			
					
					matrix[x][y] = number;
					number++;
						}
					}
					
					PX = x;
					PY = y;
					x--;
					y--;
					
					if(x<0) {
						x = length -1;
					}
					
					if(y < 0) {
						y = length - 1;
					}
					if(length-1< x) {
						x = 0;
					}
					if(length-1 < y) {
						y =0;
					}
					
					
				}
				
				
				break;
			
			case(GenerateSquare.SurOeste):
				
				while(number <= length*length) {
					System.out.println(x);
					System.out.println(y);
					if(matrix[x][y] == 0) {
						matrix[x][y] = number;
						number++;
					
					}else {
						if(matrix[PX][PY+1] == 0) {
							
						x = PX;
						y = PY+1;
					
					if(x<0) {
						x = length -1 ;
						PX = x;
					}
					if(x > length-1) {
						x = 0;
						PX = x;
					}
			
					
					matrix[x][y] = number;
					number++;
						}
					}
					
					PX = x;
					PY = y;
					x++;
					y--;
					
					if(x<0) {
						x = length -1;
					}
					
					if(y < 0) {
						y = length - 1;
					}
					if(length-1< x) {
						x = 0;
					}
					if(length-1 < y) {
						y =0;
					}
					
					
				}
				
				
				
				break;
			
			}
        	
        	break;
        
        
        
        case(GenerateSquare.Right):
        	
        	number = 1;
		length = matrix.length;
		    
		 x = 0;
		 y = 0;
		
		 PX = 0;
		 PY = 0;
		
      x = matrix.length/2;
      y = matrix.length - 1;
        	
           switch(Direction) {
			
			case(GenerateSquare.NorEste):
				
				
				 while(number <= length*length) {
						if(matrix[x][y] == 0) {
							matrix[x][y] = number;
							number++;
						
						}else {
							if(matrix[PX][PY-1] == 0) {
								
							x = PX;
							y = PY-1;
						
						if(x<0) {
							x = length -1 ;
							PX = x;
						}
						if(x > length-1) {
							x = 0;
							PX = x;
						}
				
						
						matrix[x][y] = number;
						number++;
							}
						}
						
						PX = x;
						PY = y;
						x--;
						y++;
						
						if(x<0) {
							x = length -1;
						}
						
						if(y < 0) {
							y = length - 1;
						}
						if(length-1< x) {
							x = 0;
						}
						if(length-1 < y) {
							y =0;
						}
						
						
					}
				
				break;
			
			case(GenerateSquare.SurEste):
				
				 while(number <= length*length) {
	  					
	  					if(matrix[x][y] == 0) {
	  						matrix[x][y] = number;
	  						number++;
	  					
	  					}else {
	  						if(matrix[PX][PY-1] == 0) {
	  							
	  						x = PX;
	  						y = PY-1;
	  					
	  					if(x<0) {
	  						x = length -1 ;
	  						PX = x;
	  					}
	  					if(x > length-1) {
	  						x = 0;
	  						PX = x;
	  					}
	  			
	  					
	  					matrix[x][y] = number;
	  					number++;
	  						}
	  					}
	  					
	  					PX = x;
	  					PY = y;
	  					x++;
	  					y++;
	  					
	  					if(x<0) {
	  						x = length -1;
	  					}
	  					
	  					if(y < 0) {
	  						y = length - 1;
	  					}
	  					if(length-1< x) {
	  						x = 0;
	  					}
	  					if(length-1 < y) {
	  						y =0;
	  					}
	  					
	  					
	  				}
	        		
				
				break;
			
			}
        	
        	
        	
        	break;
        
		}
		
	
		
		
		}
	
	
	
	
	public  boolean fillSquareTop(String Direction) throws NotADirectionException, NotAValidMatrixException{
		if(matrix.length % 2 == 0) {
			Direction = "Hola";
			throw new NotAValidMatrixException();
		}
		boolean decide = false;;
		int number = 1;
		int length = matrix.length;
		    
		int x = 0;
		int y = 0;
		
		int PX = 0;
		int PY = 0;
		
		y = matrix.length/2;
		
			
			
			switch(Direction) {
			
			case(GenerateSquare.NorOeste):
			
				while(number <= length*length) {
					
					if(matrix[x][y] == 0) {
						matrix[x][y] = number;
						number++;
					
					}else {
						if(matrix[PX+1][PY] == 0) {
							
						x = PX+1;
						y = PY;
					
					if(x<0) {
						x = length -1 ;
						PX = x;
					}
					if(x > length-1) {
						x = 0;
						PX = x;
					}
			
					
					matrix[x][y] = number;
					number++;
						}
					}
					
					PX = x;
					PY = y;
					x--;
					y--;
					
					if(x<0) {
						x = length -1;
					}
					
					if(y < 0) {
						y = length - 1;
					}
					if(length-1< x) {
						x = 0;
					}
					if(length-1 < y) {
						y =0;
					}
					
					
				}
				
				decide = true;
				break;
			
			case(GenerateSquare.NorEste):
				
                while(number <= length*length) {
					
					if(matrix[x][y] == 0) {
						matrix[x][y] = number;
						number++;
					
					}else {
						if(matrix[PX+1][PY] == 0) {
							
						x = PX+1;
						y = PY;
					
					if(x<0) {
						x = length -1 ;
						PX = x;
					}
					if(x > length-1) {
						x = 0;
						PX = x;
					}
			
					
					matrix[x][y] = number;
					number++;
						}
					}
					
					PX = x;
					PY = y;
					x--;
					y++;
					
					if(x<0) {
						x = length -1;
					}
					
					if(y < 0) {
						y = length - 1;
					}
					if(length-1< x) {
						x = 0;
					}
					if(length-1 < y) {
						y =0;
					}
					
					
				}
				
			decide = true;
				
				break;
				
			default:
			
			decide = false;
				throw new NotADirectionException();
				
			}
		return decide;		
					
	}
	
	
	public boolean fillSquareBot(String Direction)throws NotADirectionException, NotAValidMatrixException {
		if(matrix.length % 2 == 0) {
			Direction = null;
			throw new NotAValidMatrixException();
		}
		boolean decide = false;
		int number = 1;
		int length = matrix.length;
		    
		int x = 0;
		int y = 0;
		
		int PX = 0;
		int PY = 0;
		
		y = matrix.length/2;
        x = matrix.length - 1;	
        	
        	switch(Direction) {
        	   
        	case(GenerateSquare.SurOeste):
            
        		 while(number <= length*length) {
 					
 					if(matrix[x][y] == 0) {
 						matrix[x][y] = number;
 						number++;
 					
 					}else {
 						if(matrix[PX+1][PY] == 0) {
 							
 						x = PX+1;
 						y = PY;
 					
 					if(x<0) {
 						x = length -1 ;
 						PX = x;
 					}
 					if(x > length-1) {
 						x = 0;
 						PX = x;
 					}
 			
 					
 					matrix[x][y] = number;
 					number++;
 						}
 					}
 					
 					PX = x;
 					PY = y;
 					x++;
 					y--;
 					
 					if(x<0) {
 						x = length -1;
 					}
 					
 					if(y < 0) {
 						y = length - 1;
 					}
 					if(length-1< x) {
 						x = 0;
 					}
 					if(length-1 < y) {
 						y =0;
 					}
 					
 					
 				}
        	decide = true;
        		break;
        	
        	case(GenerateSquare.SurEste):
        		
        		 while(number <= length*length) {
  					
  					if(matrix[x][y] == 0) {
  						matrix[x][y] = number;
  						number++;
  					
  					}else {
  						if(matrix[PX+1][PY] == 0) {
  							
  						x = PX+1;
  						y = PY;
  					
  					if(x<0) {
  						x = length -1 ;
  						PX = x;
  					}
  					if(x > length-1) {
  						x = 0;
  						PX = x;
  					}
  			
  					
  					matrix[x][y] = number;
  					number++;
  						}
  					}
  					
  					PX = x;
  					PY = y;
  					x++;
  					y++;
  					
  					if(x<0) {
  						x = length -1;
  					}
  					
  					if(y < 0) {
  						y = length - 1;
  					}
  					if(length-1< x) {
  						x = 0;
  					}
  					if(length-1 < y) {
  						y =0;
  					}
  					
  					
  				}
        		
        		decide =  true;
        		break;
        		
        		default :
        			
        			decide = false;
        			throw new NotADirectionException();
        			
        			
        		
        	
        	}
        	
      
        	return decide;
	}
	
	
	public boolean fillSquareLeft(String Direction) throws NotADirectionException , NotAValidMatrixException{
		
		if(matrix.length % 2 == 0) {
			Direction = null;
			throw new NotAValidMatrixException();
	
		}
		
		boolean decide = false;
		int number = 1;
		int length = matrix.length;
		    
		int x = 0;
		int y = 0;
		
		int PX = 0;
		int PY = 0;
		
		
		 x = matrix.length/2;
     	
     	
         switch(Direction) {
			
			case(GenerateSquare.NorOeste):
				
				
       while(number <= length*length) {
					System.out.println(x);
					System.out.println(y);
					if(matrix[x][y] == 0) {
						matrix[x][y] = number;
						number++;
					
					}else {
						if(matrix[PX][PY+1] == 0) {
							
						x = PX;
						y = PY+1;
					
					if(x<0) {
						x = length -1 ;
						PX = x;
					}
					if(x > length-1) {
						x = 0;
						PX = x;
					}
			
					
					matrix[x][y] = number;
					number++;
						}
					}
					
					PX = x;
					PY = y;
					x--;
					y--;
					
					if(x<0) {
						x = length -1;
					}
					
					if(y < 0) {
						y = length - 1;
					}
					if(length-1< x) {
						x = 0;
					}
					if(length-1 < y) {
						y =0;
					}
					
					
				}
				
				
				break;
			
			case(GenerateSquare.SurOeste):
				
				while(number <= length*length) {
					System.out.println(x);
					System.out.println(y);
					if(matrix[x][y] == 0) {
						matrix[x][y] = number;
						number++;
					
					}else {
						if(matrix[PX][PY+1] == 0) {
							
						x = PX;
						y = PY+1;
					
					if(x<0) {
						x = length -1 ;
						PX = x;
					}
					if(x > length-1) {
						x = 0;
						PX = x;
					}
			
					
					matrix[x][y] = number;
					number++;
						}
					}
					
					PX = x;
					PY = y;
					x++;
					y--;
					
					if(x<0) {
						x = length -1;
					}
					
					if(y < 0) {
						y = length - 1;
					}
					if(length-1< x) {
						x = 0;
					}
					if(length-1 < y) {
						y =0;
					}
					
					
				}
				
				
				
				break;
				
				default:
					
					decide = false;
					throw new NotADirectionException();
					
			
			}
     	return decide;
		
	}
	
	
	public boolean fillSquareRight(String Direction)throws NotADirectionException , NotAValidMatrixException{
		System.out.println(Direction);
		if(matrix.length % 2 == 0) {
			Direction = null;
			throw new NotAValidMatrixException();
		
		}
		
		boolean decide = false;
		int number = 1;
		int length = matrix.length;
		    
		int x = 0;
		int y = 0;
		
		int PX = 0;
		int PY = 0;
		
		 x = matrix.length/2;
	      y = matrix.length - 1;
	        	
	           switch(Direction) {
				
				case(GenerateSquare.NorEste):
					
					
					 while(number <= length*length) {
							if(matrix[x][y] == 0) {
								matrix[x][y] = number;
								number++;
							
							}else {
								if(matrix[PX][PY-1] == 0) {
									
								x = PX;
								y = PY-1;
							
							if(x<0) {
								x = length -1 ;
								PX = x;
							}
							if(x > length-1) {
								x = 0;
								PX = x;
							}
					
							
							matrix[x][y] = number;
							number++;
								}
							}
							
							PX = x;
							PY = y;
							x--;
							y++;
							
							if(x<0) {
								x = length -1;
							}
							
							if(y < 0) {
								y = length - 1;
							}
							if(length-1< x) {
								x = 0;
							}
							if(length-1 < y) {
								y =0;
							}
							
							
						}
				decide = true;
					
					break;
				
				case(GenerateSquare.SurEste):
					
					 while(number <= length*length) {
		  					
		  					if(matrix[x][y] == 0) {
		  						matrix[x][y] = number;
		  						number++;
		  					
		  					}else {
		  						if(matrix[PX][PY-1] == 0) {
		  							
		  						x = PX;
		  						y = PY-1;
		  					
		  					if(x<0) {
		  						x = length -1 ;
		  						PX = x;
		  					}
		  					if(x > length-1) {
		  						x = 0;
		  						PX = x;
		  					}
		  			
		  					
		  					matrix[x][y] = number;
		  					number++;
		  						}
		  					}
		  					
		  					PX = x;
		  					PY = y;
		  					x++;
		  					y++;
		  					
		  					if(x<0) {
		  						x = length -1;
		  					}
		  					
		  					if(y < 0) {
		  						y = length - 1;
		  					}
		  					if(length-1< x) {
		  						x = 0;
		  					}
		  					if(length-1 < y) {
		  						y =0;
		  					}
		  					
		  					
		  				}
		        		decide = true;
					
					break;
					
					default:
						decide = false;
					 	
						throw  new NotADirectionException();
						
				
				}
	       
	        	return decide;
	}
	
	
	
	
	
	public String PrintM() {
		String s = "";
		for(int r = 0; r < matrix.length; r++) {
			for(int c = 0; c < matrix.length;c++) {
				s += matrix[r][c] + " ";
			}
			s+= "\n";
		}
		
		return s;
	}


	public int[][] getMatrix() {
		return matrix;
	}

	public void setMatrix(int[][] matrix) {
		this.matrix = matrix;
	}
	
 

}
