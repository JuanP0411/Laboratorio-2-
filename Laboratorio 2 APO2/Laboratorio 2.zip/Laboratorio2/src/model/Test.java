package model;

import Exceptions.NotADirectionException;
import Exceptions.NotAValidMatrixException;

public class Test {

	public static void main(String[] args) throws NotADirectionException, NotAValidMatrixException {
		int [][] m = new int [3][3];
		GenerateSquare gs = new GenerateSquare(m);
		gs.fillSquareTop(GenerateSquare.NorEste);
		System.out.println(gs.PrintM());
		

	}

}
