package modelTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Exceptions.NotADirectionException;
import Exceptions.NotAValidMatrixException;
import model.GenerateSquare;

class GenerateSquareTest {
	
	private GenerateSquare sq;
	private int[][] TestMatrix;
	
	
	//Escenario necesarios para las pruebas
	
	private void setupScenary() {
		int [][] n = new int[4][4];
		sq = new GenerateSquare(n);
	}
	
	private void setupScenary3() {
		int [][] n = new int[3][3];
		 sq = new GenerateSquare(n);
	}
	
	
	private void setupScenaryTNE() {
		int [][] n = new int[3][3];
		 sq = new GenerateSquare(n);
		TestMatrix =  new int [][]{{8,1,6},{3,5,7},{4,9,2}};
	}
	
	
	private void setupScenaryTNO() {
		int [][] n = new int[3][3];
		 sq = new GenerateSquare(n);
		TestMatrix =  new int [][]{{6,1,8},{7,5,3},{2,9,4}};
	}
	
	private void setupScenaryBSE() {
		int [][] n = new int[3][3];
		 sq = new GenerateSquare(n);
		TestMatrix =  new int [][]{{4,9,2},{3,5,7},{8,1,6}};
	}
	
	private void setupScenaryBSO() {
		int [][] n = new int[3][3];
		 sq = new GenerateSquare(n);
		TestMatrix =  new int [][]{{2,9,4},{7,5,3},{6,1,8}};
	}
	
	private void setupScenaryLSO() {
		int [][] n = new int[3][3];
		 sq = new GenerateSquare(n);
		TestMatrix =  new int [][]{{8,3,4},{1,5,9},{6,7,2}};
	
	}
		private void setupScenaryLNO() {
			int [][] n = new int[3][3];
			 sq = new GenerateSquare(n);
			TestMatrix =  new int [][]{{6,7,2},{1,5,9},{8,3,4}};
		}
		
		private void setupScenaryRNE() {
			int [][] n = new int[3][3];
			 sq = new GenerateSquare(n);
			TestMatrix =  new int [][]{{2,7,6},{9,5,1},{4,3,8}};
		}
		private void setupScenaryRSE() {
			int [][] n = new int[3][3];
			 sq = new GenerateSquare(n);
			TestMatrix =  new int [][]{{4,3,8},{9,5,1},{2,7,6}};
		}
		private void setupScenaryBlank() {
			TestMatrix =  new int [][]{{8,1,6},{3,5,7},{4,9,2}};
		}
		
		
		@Test
		void CombrobarConstructor() {
			setupScenaryBlank();
			GenerateSquare qs = new GenerateSquare(TestMatrix);
			assertFalse(qs == null, "No funciona el constructor");
		}
		
		@Test
		void CombrobarGetter() {
			setupScenaryBlank();
			GenerateSquare qs = new GenerateSquare(TestMatrix);
			assertTrue(qs.getMatrix() == TestMatrix,"No devuelve la matriz");
			
		}
		
		@Test
		void  ComprobarSetter() {
			setupScenaryBlank();
			int [][] m = {{6,1,8},{7,5,3},{2,9,4}};
			GenerateSquare qs = new GenerateSquare(TestMatrix);
			qs.setMatrix(m);
			boolean decide = true;
			
			for(int c = 0; c < m.length;c++) {
				for(int r = 0; r < m.length; r++) {
					if(m[c][r] == qs.getMatrix()[c][r]){
						decide = false;
					}
				}
			}
			
			assertFalse(decide,"El setter no cambia el valor del atributo");
			
			
		}
		
	
	//Pruebas para la pocision superior
	
	@Test
	void ComprobarRecoridoTopSO() throws NotADirectionException, NotAValidMatrixException {
		
		setupScenary3();
		boolean a = true;
		String Direction = GenerateSquare.SurOeste;
		try {
			a = sq.fillSquareTop(Direction);
		}catch(NotADirectionException e) {
			a = false;
		}
		
		
		assertFalse(a, "No se pude hacer este recorrido");
	
	}
	
	@Test
	void ComprobarRecorridoTopSE() throws NotADirectionException, NotAValidMatrixException {
		
		setupScenary3();
		String Direction = GenerateSquare.SurEste;
		
		boolean a = true;
		try {
			 a = sq.fillSquareTop(Direction);
		}catch(NotADirectionException e) {
			a = false;
		
		}
		
		assertFalse(a, "No se pude hacer este recorrido");
		
	}
	
	@Test
	
	void ComprobarPosibleRecoridoTop() throws NotADirectionException, NotAValidMatrixException {
		
		setupScenary3();
		String Direction = "Hola";
		boolean a = true;
		try {
			 a = sq.fillSquareTop(Direction);
		}catch(NotADirectionException e) {
			a = false;
		
		}
		
		assertFalse(a, "No se pude hacer este recorrido");

		
	}
	
	@Test
	
	void ComprobarLongitudDeMatrizTop() throws NotADirectionException, NotAValidMatrixException {
		setupScenary();
		String Direction = GenerateSquare.NorEste;
		boolean a = true;
		
		try {
			 a = sq.fillSquareRight(Direction);
		}catch(NotAValidMatrixException e) {
			a = false;
		}
		
		assertFalse(a,"La longitud de la matriz es par no se pude hacer el recorrido");
		
	}
	
	@Test
	void ComprobarCreacionMatrizTopNE() throws NotADirectionException, NotAValidMatrixException {
		setupScenaryTNE();
		
		String Direction = GenerateSquare.NorEste;
		sq.fillSquareTop(Direction);
		boolean a = true;
		
		for(int c = 0; c < sq.getMatrix().length;c++) {
			for(int r = 0; r < sq.getMatrix().length; r++) {
				if(sq.getMatrix()[c][r] != TestMatrix[c][r]) {
					a = false;
				}
			}
			
		}
		
		assertTrue(a, "Algo esta mal");
		
	}
	
	@Test
	void ComprobarCreacionMatrizTopNO() throws NotADirectionException, NotAValidMatrixException {
		
setupScenaryTNO();
		
		String Direction = GenerateSquare.NorOeste;
		sq.fillSquareTop(Direction);
		boolean a = true;
		
		for(int c = 0; c < sq.getMatrix().length;c++) {
			for(int r = 0; r < sq.getMatrix().length; r++) {
				if(sq.getMatrix()[c][r] != TestMatrix[c][r]) {
					a = false;
				}
			}
			
		}
		
		assertTrue(a, "Algo esta mal");
	}
	
	
	// Pruebas para la pocision inferior
	
	@Test
	void ComprobarRecoridBotNO() throws NotADirectionException, NotAValidMatrixException {
		
		setupScenary3();
		String Direction = GenerateSquare.NorOeste;
		
		assertTrue(sq.fillSquareTop(Direction), "No se pude hacer este recorrido");
	
	}
	
	@Test
	void ComprobarRecorridoBotNE() throws NotADirectionException, NotAValidMatrixException {
		
		setupScenary3();
		String Direction = GenerateSquare.NorEste;
		
		boolean a = true;
		try {
			a = sq.fillSquareBot(Direction);
		}catch(NotADirectionException e) {
			a = false;
		}
		
		assertFalse(a, "No se pude hacer este recorrido");
		
	}
	
	@Test
	
	void ComprobarPosibleRecoridoBot() throws NotADirectionException, NotAValidMatrixException {
		
		setupScenary3();
		String Direction = "Hola";
		boolean a = true;
		try {
			 a = sq.fillSquareBot(Direction);
		}catch(NotADirectionException e) {
			a = false;
		
		}
		
		assertFalse(a, "No se pude hacer este recorrido");

		
	}
	
	@Test
	
	void ComprobarLongitudDeMatrizBot() throws NotADirectionException, NotAValidMatrixException {
		setupScenary();
		String Direction = GenerateSquare.SurEste;
		boolean a = true;
	
		try {
			 a = sq.fillSquareRight(Direction);
		}catch(NotAValidMatrixException e) {
			a = false;
		}
		
		assertFalse(a,"La longitud de la matriz es par no se pude hacer el recorrido");
		
	}
	
	@Test
	void ComprobarCreacionMatrizBotSE() throws NotADirectionException, NotAValidMatrixException {
		setupScenaryBSE();
		
		String Direction = GenerateSquare.SurEste;
		sq.fillSquareBot(Direction);
		boolean a = true;
		for(int c = 0; c < sq.getMatrix().length;c++) {
			for(int r = 0; r < sq.getMatrix().length; r++) {
				if(sq.getMatrix()[c][r] != TestMatrix[c][r]) {
				
					a = false;
				
				}
			}
			
		}
		System.out.println(sq.PrintM());
		assertFalse(a, "Algo esta mal");
	
	}
	
	@Test
	void ComprobarCreacionMatrizBotSO() throws NotADirectionException, NotAValidMatrixException {
		
		setupScenaryBSO();
		String Direction = GenerateSquare.SurOeste;
		sq.fillSquareBot(Direction);
		boolean a = true;
		
		
		for(int c = 0; c < sq.getMatrix().length;c++) {
			for(int r = 0; r < sq.getMatrix().length; r++) {
				if(sq.getMatrix()[c][r] == TestMatrix[c][r]) {
					a = false;
					
				}
		
			}
			
		}
	
		assertFalse(a, "Algo esta mal");
	}
	


	// Pruebas para la pocision izquierda
	
	
	
	@Test
	void ComprobarRecoridLeftNE() throws NotAValidMatrixException, NotADirectionException {
		
		setupScenary3();
		boolean a = true;
		String Direction = GenerateSquare.NorEste;	
		try {
			a = sq.fillSquareLeft(Direction);
		}catch(NotADirectionException e) {
			a = false;
		}
		assertFalse(a, "No se pude hacer este recorrido");
	
	}
	
	@Test
	void ComprobarRecorridoLeftSE() throws NotADirectionException, NotAValidMatrixException {
		
		setupScenary3();
		String Direction = GenerateSquare.SurEste;
		boolean a = true;
		try {
			 a = sq.fillSquareLeft(Direction);
		}catch(NotADirectionException e) {
			a = false;
		
		}
	
		assertFalse(a, "No se pude hacer este recorrido");
		
	}
	
	@Test
	
	void ComprobarPosibleRecoridoLeft() throws NotADirectionException, NotAValidMatrixException {
		
		setupScenary3();
		String Direction = "Hola";
		
		boolean a = true;
		try {
			 a = sq.fillSquareLeft(Direction);
		}catch(NotADirectionException e) {
			a = false;
		
		}
		
		
		assertFalse(a, "No se pude hacer este recorrido");

		
	}
	
	@Test
	
	void ComprobarLongitudDeMatrizLeft() throws NotADirectionException, NotAValidMatrixException {
		setupScenary();
		String Direction = GenerateSquare.NorOeste;
		
		boolean a = true;
		
		try {
			 a = sq.fillSquareRight(Direction);
		}catch(NotAValidMatrixException e) {
			a = false;
		}
		
		assertFalse(a,"La longitud de la matriz es par no se pude hacer el recorrido");
		
	}
	
	@Test
	void ComprobarCreacionMatrizleftSO() throws NotADirectionException, NotAValidMatrixException {
		setupScenaryLSO();
		
		String Direction = GenerateSquare.SurOeste;
		sq.fillSquareLeft(Direction);
		boolean a = true;
		
		for(int c = 0; c < sq.getMatrix().length;c++) {
			for(int r = 0; r < sq.getMatrix().length; r++) {
				if(sq.getMatrix()[c][r] != TestMatrix[c][r]) {
					a = false;
				}
			}
			
		}
		
		assertTrue(a, "Algo esta mal");
		
	}
	
	@Test
	void ComprobarCreacionMatrizLeftNO() throws NotADirectionException, NotAValidMatrixException {
		
		setupScenaryLNO();
		String Direction = GenerateSquare.NorOeste;
		sq.fillSquareLeft(Direction);
		boolean a = true;
		
		for(int c = 0; c < sq.getMatrix().length;c++) {
			for(int r = 0; r < sq.getMatrix().length; r++) {
				if(sq.getMatrix()[c][r] != TestMatrix[c][r]) {
				
					a = false;
				}
				
		}
		
		assertTrue(a, "Algo esta mal");
	}
	}
	
	
	// Pruebas para la pocision Derecha
	
	@Test
	void ComprobarRecoridRightNO() throws NotADirectionException, NotAValidMatrixException {
		
		setupScenary3();
		String Direction = GenerateSquare.NorOeste;
		boolean a = true;
	
		try {
			 a = sq.fillSquareRight(Direction);
		}catch(NotADirectionException e) {
			a = false;
		}
		
		assertFalse(a, "No se pude hacer este recorrido");
	
	}
	
	@Test
	void ComprobarRecorridoRightSO() throws NotADirectionException, NotAValidMatrixException {
		
		setupScenary3();
		String Direction = GenerateSquare.SurOeste;
		boolean a = true;
		
		try {
			 a = sq.fillSquareRight(Direction);
		}catch(NotADirectionException e) {
			a = false;
		}
		
		assertFalse(a, "No se pude hacer este recorrido");
		
	}
	
	@Test
	
	void ComprobarPosibleRecoridoRight() throws NotADirectionException, NotAValidMatrixException {
		
		setupScenary3();
		String Direction = "Hola";
		boolean a = true;
		try {
			 a = sq.fillSquareRight(Direction);
		}catch(NotADirectionException e) {
			a = false;
		}
		
		assertFalse(a, "No se pude hacer este recorrido");

		
	}
	
	@Test
	
	void ComprobarLongitudDeMatrizRight() throws NotADirectionException, NotAValidMatrixException {
		setupScenary();
		String Direction = GenerateSquare.NorEste;
		boolean a = true;
		try {
			 a = sq.fillSquareRight(Direction);
		}catch(NotAValidMatrixException e) {
			a = false;
		}
		
		assertFalse(a,"La longitud de la matriz es par no se pude hacer el recorrido");
		
	}
	
	@Test
	void ComprobarCreacionMatrizRightSE() throws NotADirectionException, NotAValidMatrixException {
		setupScenaryRSE();
		
		String Direction = GenerateSquare.SurEste;
		boolean a = true;
		try {
		sq.fillSquareRight(Direction);
		}catch(NotAValidMatrixException e){
			
		}
		
		for(int c = 0; c < sq.getMatrix().length;c++) {
			for(int r = 0; r < sq.getMatrix().length; r++) {
				if(sq.getMatrix()[c][r] != TestMatrix[c][r]) {
					a = false;
				}
			}
			
		}
		
		assertTrue(a, "Algo esta mal");
		
	}
	
	@Test
	void ComprobarCreacionMatrizRighttNE() throws NotADirectionException, NotAValidMatrixException {
		
		setupScenaryRNE();
		String Direction = GenerateSquare.NorEste;
		sq.fillSquareRight(Direction);
		boolean a = true;
		
		for(int c = 0; c < sq.getMatrix().length;c++) {
			for(int r = 0; r < sq.getMatrix().length; r++) {
				if(sq.getMatrix()[c][r] != TestMatrix[c][r]) {
					a = false;
				}
			}
			
		}
		
		assertTrue(a, "Algo esta mal");
	}
	
	



}
