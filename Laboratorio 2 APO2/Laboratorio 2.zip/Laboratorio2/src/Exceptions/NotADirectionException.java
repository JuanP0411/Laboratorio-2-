package Exceptions;
 
@SuppressWarnings("serial")
public class NotADirectionException extends Exception{
	public NotADirectionException() {
	super("No se pude llenar el cuadarado magico por esta direccion cuando se empieza por la pocision elegida");
	}
	

}
