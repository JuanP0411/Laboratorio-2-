package Exceptions;

@SuppressWarnings("serial")
public class NotAValidMatrixException extends Exception{
	
	public NotAValidMatrixException() {
		super("La longitud de la matriz no es impar , o no son las mismas");
	}

}
