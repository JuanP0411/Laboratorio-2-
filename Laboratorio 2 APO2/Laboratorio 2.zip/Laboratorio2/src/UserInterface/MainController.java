package UserInterface;

import javax.swing.JOptionPane;

import com.sun.prism.paint.Color;

import Exceptions.NotADirectionException;
import Exceptions.NotAValidMatrixException;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import model.*;

public class MainController {
	    @FXML
	    private BorderPane BDCentral;

	    @FXML
	    private GridPane BTCreate;

	    @FXML
	    private TextField txtSide;

	    @FXML
	    private TextField txtMagic;

	    @FXML
	    private TextField txtDireccion;

	    @FXML
	    private Label LBMessage;
	    
	    @FXML
	    private TextField txtPosition;
	    
	    
	    
	    public void createMagicSquare() throws NotADirectionException, NotAValidMatrixException {
	    	
	    	boolean decide = true;
	    	GridPane MainGrid = new GridPane();
	    	String direction = txtDireccion.getText();
	    	
	    	int side = Integer.parseInt(txtSide.getText());
	    	String position = txtPosition.getText();
	    	
	    	int[][] matrix = new int[side][side];
	    	GenerateSquare GS = new GenerateSquare(matrix);
	    	
	    	
	    	
	    	
	    switch(position) {
	    
	    case(GenerateSquare.Top):
	    	try {
	    	GS.fillSquareTop(direction);
	    	}catch(NotAValidMatrixException e) {
	    		JOptionPane.showMessageDialog(null,e.getMessage());
	    		decide = false;
	    	}catch(NotADirectionException e){
	    		JOptionPane.showMessageDialog(null,e.getMessage());
	    		decide = false;
	    	}
	    
	    
	    break;
	    
	    case(GenerateSquare.Bot):
	    	
	    	try {
		    	GS.fillSquareBot(direction);	    	
		    	}catch(NotAValidMatrixException e) {
		    	
		    		decide = false;
		    		JOptionPane.showMessageDialog(null,e.getMessage());
		    		BDCentral.getChildren().remove(MainGrid);
		    	}catch(NotADirectionException e){
		    		decide = false;
		    		JOptionPane.showMessageDialog(null,e.getMessage());
		    		BDCentral.getChildren().remove(MainGrid);
		    	}
	    
	    	
	    	break;
	    	
	    case(GenerateSquare.Left):
	    	
	    	try {
		    	GS.fillSquareLeft(direction);	    	
		    	}catch(NotAValidMatrixException e) {
		    		JOptionPane.showMessageDialog(null,e.getMessage());
		    		decide = false;
		    		BDCentral.getChildren().remove(MainGrid);
		    	}catch(NotADirectionException e){
		    		JOptionPane.showMessageDialog(null,e.getMessage());
		    		decide = false;
		    		BDCentral.getChildren().remove(MainGrid);
		    	}
	   
	    break;
	    
	    case(GenerateSquare.Right):
	    	
	    	try {
		    	GS.fillSquareTop(direction);	    	
		    	}catch(NotAValidMatrixException e) {
		    		JOptionPane.showMessageDialog(null,e.getMessage());
		    		decide = false;
		    		BDCentral.getChildren().remove(MainGrid);
		    	}catch(NotADirectionException e){
		    		JOptionPane.showMessageDialog(null,e.getMessage());
		    		decide = false;
		    		BDCentral.getChildren().remove(MainGrid);
		    	}
	   
	   
	   default:
		   JOptionPane.showMessageDialog(null,"No es una pocision valida para el cuadrado");
		   decide = false;
		   break;
	    
	    }
	    	while(decide == true) {
	    		
	    	
	    	
	    	MainGrid.setAlignment(Pos.CENTER);
	    	MainGrid.setVisible(true);
	    	
	    	Button [][] BTMatrix = new Button[side][side];
	    	
	    	txtMagic.setText(Integer.toString(GS.MagicC(side)));
	    	
	    	for(int r = 0; r < side + 2; r++) {
	
	    		MainGrid.addRow(r);
	    		MainGrid.addColumn(r);
	    	
	    	}
	    	
	    	
	    	
	    	
	    	for(int r = 1; r <= side;r++) {
	    		for(int c = 1; c <= side; c++) {
	    			Button bt = new Button();
	    			bt.setText(Integer.toString(GS.getMatrix()[r-1][c-1]));
	    			bt.setOnAction(new EventHandler <ActionEvent> () {
 
						@Override
						public void handle(ActionEvent event) {
							
							
						
							for(int r = 0; r < side ; r++) {
								for(int c = 0; c < side; c++) {
									BTMatrix[r][c].setStyle("-fx-background-color : lightgrey");
								}
							}
							
							for(int c = 0; c < side; c++) {
								
								
								Label LB1 = new Label();
								Label LB2 = new Label();
								Label LB3 = new Label();
								Label LB4 = new Label();
								
								
							
								
								LB1.setText(Integer.toString(GS.MagicC(side)));
								LB2.setText(Integer.toString(GS.MagicC(side)));
								LB3.setText(Integer.toString(GS.MagicC(side)));
								LB4.setText(Integer.toString(GS.MagicC(side)));
								
								
								BTMatrix[c][GridPane.getRowIndex(bt)-1].setStyle("-fx-background-color : red;");
								BTMatrix[GridPane.getColumnIndex(bt)-1][c].setStyle("-fx-background-color : red;");
								
								MainGrid.add(LB1, GridPane.getColumnIndex(bt),side+1);
								MainGrid.add(LB2, side+1, GridPane.getRowIndex(bt));
								MainGrid.add(LB3, 0, GridPane.getRowIndex(bt));
								MainGrid.add(LB4,   GridPane.getColumnIndex(bt),0);
							}
							
								
						}
	    				
	    			});
	    			System.out.println(bt.getText());
	    			MainGrid.add(bt, c, r);
	    			BTMatrix[r-1][c-1] = bt;
	    		}
	    	}
	    	BDCentral.setCenter(MainGrid);
	    	decide = false;
	    }
	    	
	    	
	    }

}
