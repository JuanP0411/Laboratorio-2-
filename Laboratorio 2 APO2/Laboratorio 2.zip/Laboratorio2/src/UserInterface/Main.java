 package UserInterface;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.stage.Stage;
import javafx.fxml.*;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class Main extends Application{

	@Override
	public void start(Stage Stage) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("Laboratorio1.fxml"));
		Scene scene = new Scene(root);
		Stage.setTitle("Magic Square");
		Stage.setScene(scene);
		Stage.show();
	}
	
	public static void main(String [] args) {
		launch(args);
	}

}
